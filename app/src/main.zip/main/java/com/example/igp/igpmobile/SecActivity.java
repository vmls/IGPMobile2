package com.example.igp.igpmobile;

/**
 * Created by vimal on 9/12/15.
 */
public class SecActivity extends BaseActivity {

}
