package com.example.igp.igpmobile.utilities.network.APIdata;

/**
 * Created by vimal on 10/12/15.
 */
public class LoginRequestApiData {
    private String userHashCode;
    private String userEmail;

    public String getUserHashCode() {
        return userHashCode;
    }

    public void setUserHashCode(String userHashCode) {
        this.userHashCode = userHashCode;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
}
