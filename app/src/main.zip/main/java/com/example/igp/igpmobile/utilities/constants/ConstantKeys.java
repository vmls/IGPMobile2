package com.example.igp.igpmobile.utilities.constants;

/**
 * Created by vimal on 10/12/15.
 */
public class ConstantKeys {

    public static final int LOGIN_GOOGLE = 1001;
    public static final int TEST_KEY = 1002;
}
